$('.datepicker').each(function(){
	var picker = new Pikaday({
		field: this
	});
});